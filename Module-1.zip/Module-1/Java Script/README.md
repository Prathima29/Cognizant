it contains javascript files
